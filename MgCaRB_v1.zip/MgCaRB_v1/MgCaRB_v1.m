%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MgCaRB: Compute salinity and pH adjusted planktonic Mg/Ca SST
%
% If this function is useful to your research, please cite:
% Gray & Evans [2019] Non?thermal influences on Mg/Ca in planktonic foraminifera: 
%   A review of culture studies and application to the last glacial maximum
%   Paleoceanography & Paleoclimatology doi.org/10.1029/2018PA003517
%
% An R version of this program is available at https://github.com/willyrgray
%
% Format (see below for examples of how to call the function):
%
% [TOut,pHOut,TOutRel] = ...
%    MgCaRB_v1(age,MgCa,species,generic,relative,TAlk,DpCO2,d11B,sal,unc,fig)
%
% Note all input fields are mandatory:
% 1. age in ka
% 2. Mg/Ca in mmol/mol. If only one column is given then analytical uncertainty
%   is prescribed to be +/-2%
% 3. Species ID (1=G. ruber, 1.1=G. ruber using the sed. trap data of 
%   Gray et al. [2018], 2=T. sacculifer, 3=G. bulloides, 4=O.universa,
%   5='multi-species')
% 4. generic? (1/0) Use the 'generic' (multi-species) T and S sensitivities
%   but the species-specific pH sensitivity (see the SI)
% 5. relative? - absolute (enter 0) or delta temperature (enter end +/-
%    start age, if no start age is given then 0 ka is used)
% 6. TAlk - modern site alkalinity
% 7. DpCO2 - modern site CO2 disequilibrium if CO2 is to be used (or enter 0)
% 8. d11B - d11B pH record if available which must be in units of d11BOH4
%   (enter 0 if pCO2 is to be used). Can be two column with uncertainties.
% 9. sal - modern site salinity or a vector of salinity values
% 10. unc - Monte-Carlo uncertainty simulation? (1/0/n) If '1', n=1000 is
%    default, or specify n manually. 
% 11. fig - plot data? (1/0)
%
%
% OUTPUT can be two or three variables depending on whether relative is set
% to 0 or 1. If the MonteCarlo uncertainty simulation is to be performed,
% 'TOut', 'pHOut', 'TOutRel' all return an n*5 matrix, where n
% is the number of samples with a valid age (currently 0-156 ka), and the
% five columns represent the lower 2SD, lower 1SD, 50th percentile, upper
% 1SD and upper 2SD of the MC results, respectively. If no uncertainty
% simulation is performed then the output variables are n*1 vectors.
%
%
% EXAMPLES
%
% [TOut,pHOut,TOutRel] = MgCaRB_v1(age,MgCa,1,1,[0 10],2350,0,0,35,500,1)
%   Use the generic G. ruber calibration, calculate relative temp. change
%   relative to the mean of all data in the interval 0-10 ka,
%   pH correct using atmospheric CO2 assuming no ocean-atmosphere
%   disequilibrium at this site, perform the MC simulation with n=500,
%   and draw a figure
%
% [TOut,pHOut,TOutRel] = MgCaRB_v1(age,MgCa,5,0,[5 10],[],[],d11B,35,1,1)
%   Use the multi-species calibration, calculate relative temp. change
%   relative to the mean of all data in the interval 5-10 ka,
%   pH correct using a d11BOH4 record, perform the MC simulation with n=1000,
%   and draw a figure. Note empty TAlk and DpCO2 fields as pH is derived
%   from d11BOH4
%
%
% MgCaRB depends on the following data/functions, which you may also wish
% to cite where appropriate:
%   Bereiter, B., S. Eggleston, J. Schmitt, C. Nehrbass-Ahles, T. F. Stocker,
%      H. Fischer, S. Kipfstuhl, and J. Chappellaz (2015), Revision of the
%       EPICA Dome C CO2 record from 800 to 600 kyr before present,
%       Geophys. Res. Lett., 42, doi:10.1002/2014GL061957. 
%   Lewis, E., and D. W. R. Wallace. 1998. Program Developed for
%       CO2 System Calculations. ORNL/CDIAC-105. Carbon Dioxide Information
%       Analysis Center, Oak Ridge National Laboratory, U.S. Department of Energy,
%       Oak Ridge, Tennessee. http://cdiac.ornl.gov/oceans/co2rprt.html
%   Spratt, R.M., Lisiecki, L.E. 2016. A late Pleistocene sea level stack.
%       Clim. Past, 12, 1079�1092, 2016
%
% TO DO
% - co2/sea level age unc.
% - print to csv
%
% To come in a future release:
% - co2 & sea level back to 800 ka
%
%
function [TOut,pHOut,TOutRel] = ...
    MgCaRB_v1(age,MgCa,species,generic,relative,TAlk,DpCO2,d11B,sal,unc,fig)

age = age(:);   % reshape inputs
if min(size(MgCa))>1 && size(MgCa,1)<size(MgCa,2)
    MgCa = MgCa';
elseif size(MgCa,1)<size(MgCa,2)
    MgCa = MgCa(:);
end
if min(size(d11B))>1 && size(d11B,1)<size(d11B,2)
    d11B = d11B';
elseif size(d11B,1)<size(d11B,2)
    d11B = d11B';
end

load('lookup_data','seaLevel','pCO2')

if numel(sal)==1    % if salinity data not prescribed
    salinity = interp1(seaLevel(:,1),seaLevel(:,2:4),age); % interpolate sea level from input
    salinity = sal + salinity./min(seaLevel(:,2)).*0.7; % salinity scaled from sea level
else
    salinity = sal;
end
if ~isempty(DpCO2)
    atmosCO2 = interp1(pCO2(:,1),pCO2(:,2:2),age) + DpCO2;    % CO2 interpolated from input
end

d11Bsw = 39.61;

% user input warnings/errors
if nargout<3 && max(relative)>0
    warning(['no output variable specified for delta T;',...
        ' only absolute T will be returned.'])
end
if ~isempty(TAlk) && abs(TAlk-2400)>500 || ~isempty(DpCO2) && abs(DpCO2)>150 || abs(sal-35)>5
    warning(['unexpected TAlk, DpCO2, and/or salinity input. The calculation',...
        ' will be attempted but please double-check these values.'])
end
if max(age(:,1))>156
    warning(['samples older than 156 ka will be computed in a future release!',...
        ' Only younger sample data processed for now.'])
    MgCa(age>156,:) = [];
    if d11B~=0
        d11B(age>156,:) = [];
    end
    age(age>156) = [];
end
if d11B==0
    if unc==1 || unc>99
        warning(['this function depends on co2sys.m in an iterative loop,',...
            ' which is not very fast. A MC simulation with n=1000 takes ~15 s',...
            ' per data point. Ctrl-C can be used to break the function.'])
    end
end


if relative(1)~=0 || relative(1)==0 && numel(relative)>1 % isolate relative age data points
    if max(size(relative))==1
        relative = [0 relative];
    end
    HolAge = age(ge(age,relative(1)) & ge(relative(2),age));
    if size(HolAge,1)==0
        error('No Holocene data! Cannot compute relative T.')
    end
    [~,idx] = ismember(HolAge,age);
end

if generic==0   % use species-specific sensitivities
    if species==1   % calibration choice - G.ruber (w)
        a = 0.03538; b = 0.06388; c = -0.87005;
        a1 = 0.01318; b1 = 0.01785; c1 = 0.11844;
        intCov = @(n) 1.563359 - 25.016445.*n;   % covariance of intercept & T-sens. for unc. prop. (see SI)
        intCovErr = 0.0002490649;
    elseif species==1.1   % G.ruber Dr. Gray et al. [2018] sed. trap
        a = 0.03313; b = 0.059759; c = -0.83263;
        a1 = 0.01118; b1 = 0.00376; c1 = 0.16933;
        intCov = @(n) 1.83279 - 29.18481.*n;
        intCovErr = 0.0001141005;
    elseif species==2   % T.sacculifer
        a = 0.053976; b = 0.062413; c = 0;
        a1 = 0.009464; b1 = 0.017841; c1 = 0.0844;
        intCov = @(n) 1.365102 - 25.704721.*n;
        intCovErr = 0.0001442152;
    elseif species==3   % G.bulloides
        a = 0.032966; b = 0.06411; c = -0.87527;
        a1 = 0.006176; b1 = 0.03110; c1 = 0.13025;
        intCov = @(n) 1.564222 - 22.053373.*n;
        intCovErr = 0.0002023524;
    elseif species==4   % O.universa
        a = 0.04004; b = 0.07461; c = -0.49577;
        a1 = 0.01427; b1 = 0.01210; c1 = 0.12053;
        intCov = @(n) 2.091911 - 21.679394.*n;
        intCovErr = 0.0001874262;
    else                % generic
        a = 0.036136; b = 0.061249; c = -0.73150;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.07245;
        intCov = @(n) 1.5 - 25.*n;
        intCovErr = 0.0002490649;
    end
else        % use generic T and S sensitivities
    if species==1   % calibration choice - G.ruber (w)
        a = 0.036136; b = 0.061249; c = -0.87309;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.10969;
        intCov = @(n) 1.623660 - 25.960728.*n;   % covariance of intercept & T-sens. for unc. prop. (see SI)
        intCovErr = 0.000197117;
    elseif species==1.1   % G.ruber Dr. Gray et al. [2018] sed. trap
        a = 0.03313; b = 0.059759; c = -0.83263;
        a1 = 0.01118; b1 = 0.00376; c1 = 0.16933;
        intCov = @(n) 1.83279 - 29.18481.*n;
        intCovErr = 0.0001141005;
    elseif species==2   % T.sacculifer
        a = 0.036136; b = 0.061249; c = 0.0;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.0844;
        intCov = @(n) 1.39803 - 25.90757.*n;
        intCovErr = 0.0001313673;
    elseif species==3   % G.bulloides
        a = 0.036136; b = 0.061249; c = -0.87738;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.12103;
        intCov = @(n) 1.525943 - 21.442429.*n;
        intCovErr = 0.0002160964;
    elseif species==4   % O.universa
        a = 0.036136; b = 0.061249; c = -0.50927;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.11786;
        intCov = @(n) 2.136308 - 22.297933.*n;
        intCovErr = 0.000200698;
    else                % generic
        a = 0.036136; b = 0.061249; c = -0.73150;
        a1 = 0.006176; b1 = 0.005239; c1 = 0.07245;
        intCov = @(n) 1.5 - 25.*n;
        intCovErr = 0.0002490649;
    end 
end

if unc==0
    pH = NaN(size(age,1),1);
    MgTemp = NaN(size(age,1),1);
    T = repmat(25,100,1);
    if d11B==0      % if no d11B record, use atmospheric CO2
        for i = 1:size(age,1)
            t = 10;
            z = 1;
            while t>0.001   %iteratively solve for temp+pH
                z = z+1;
                carbSys = ...
                    CO2SYS(TAlk,atmosCO2(i,1),1,4,salinity(i,1),T(z-1),T(z-1),0,0,15,1,1,10,1);
                pH(i) = carbSys(:,3);       % pH not output
                T(z) = MgCa(i)./exp(a.*(salinity(i,1)-35) + (pH(i)-8).*c + intCov(b));
                T(z) = log(T(z))./b;
                t = abs(T(z)-T(z-1));
            end
            MgTemp(i) = T(z);
        end
    else        % use d11B
        for i = 1:size(age,1)
            t = 10;
            z = 1;
            while t>0.001
                z = z+1;
                KB = (-8966.9 -2890.53*salinity(i,1)^0.5 - 77.942*salinity(i,1) +...
                    1.728*salinity(i,1)^1.5 - 0.0996*salinity(i,1)^2)/(T(z-1)+273.15) + ...
                    (148.0248 + 137.1942*salinity(i,1)^0.5 + 1.62142*salinity(i,1)) + ...
                    (-24.4344 - 25.085*salinity(i,1)^0.5 - 0.2474*salinity(i,1))*log((T(z-1)+273.15)) + ...
                    0.053105*salinity(i,1)^0.5*(T(z-1)+273.15);
                pKB = -log10(exp(KB));
                pH(i) = pKB - log10(-((d11Bsw-d11B(i))/(d11Bsw-(1.0272*d11B(i)) - 1000*(1.0272 - 1))));
                T(z) = MgCa(i)./exp(a.*(salinity(i,1)-35) + (pH(i)-8).*c + intCov(b));
                T(z) = log(T(z))./b;
                t = abs(T(z)-T(z-1));
            end
            MgTemp(i) = T(z);
        end
    end
    if relative(1)~=0 && numel(relative)>1
        HolTemp = nanmean(MgTemp(idx(1):idx(size(idx,1))));
        MgTempRel = MgTemp - HolTemp;
    end

    
else    % perform uncertianty analysis
    if unc>1    % user n MC simulations?
        mCN = unc;
    else
        mCN = 1000;
    end
    pH = NaN(size(age,1),mCN);
    MgTemp = NaN(size(age,1),mCN);
    MgTempRel = NaN(size(age,1),mCN); 
    T = repmat(25,100,mCN);
    errInt = [normrnd(a,a1/2,mCN,1) normrnd(b,b1/2,mCN,1) normrnd(c,c1/2,mCN,1)];
    errInt(:,4) = normrnd(intCov(errInt(:,2)),intCovErr,mCN,1);  % take intercept from covariance
    if d11B==0  % use pCO2
        %tic;
        f = waitbar(0,'running...','Name','Uncertainty simulation');
        errEx = NaN(4,size(age,1),mCN);
        for i = 1:size(age,1)   % normal random external errors
            if size(MgCa,2)==1  % Mg/Ca uncertainty not given,use 2% of value
                errEx(1,i,:) = normrnd(MgCa(i,1),MgCa(i,1).*0.01,1,mCN);
            else        % use value
                errEx(1,i,:) = MgCa(i,1)-MgCa(i,2) + 2.*MgCa(i,2).*rand(1,mCN);
            end
                errEx(2,i,:) = normrnd(0,20,1,mCN); % pCO2 unc.
                errEx(3,i,:) = normrnd(salinity(i,1),1,1,mCN); % sal. unc.
                errEx(4,i,:) = rand(1,mCN).*100 + TAlk-25; % TAlk unc. (flat dist.)
        end
        for j = 1:mCN
            for i = 1:size(age,1)
                t = 10;
                z = 1;
                while t>0.001   %iteratively solve for temp+pH
                    z = z+1;
                    carbSys = CO2SYS(errEx(4,i,j),atmosCO2(i,1)+errEx(2,i,j),1,4,...
                        errEx(3,i,j),T(z-1,j),T(z-1,j),0,0,15,1,1,10,1);
                    pH(i,j) = carbSys(:,3);       % pH not output
                    T(z,j) = (errEx(1,i,j))./exp(errInt(j,1).*(errEx(3,i,j)-35) + ...
                        (pH(i,j)-8).*errInt(j,3) + errInt(j,4));% (d+err(1,5)*d1));
                    T(z,j) = log(T(z,j))./errInt(j,2);
                    t = abs(T(z,j)-T(z-1,j));
                end
                MgTemp(i,j) = T(z,j);
            end
            waitbar(j/mCN,f)
        end
        close(f)
        %toc
    else
        errEx = NaN(5,size(age,1),mCN);
        for i = 1:size(age,1)   % normal random external errors
            if size(MgCa,2)==1  % Mg/Ca uncertainty not given,use 2% of value
                errEx(1,i,:) = normrnd(MgCa(i,1),MgCa(i,1).*0.01,1,mCN);
            else        % use value
                errEx(1,i,:) = MgCa(i,1)-MgCa(i,2) + 2.*MgCa(i,2).*rand(1,mCN);
            end
                errEx(2,i,:) = normrnd(0,20,1,mCN); % pCO2 unc.
                errEx(3,i,:) = normrnd(salinity(i,1),1,1,mCN); % sal. unc. 
            if size(d11B,2)==1  % d11B uncertainty not given, no. unc. prop
                errEx(4,i,:) = normrnd(d11B(i,1),0,1,mCN);
            else        % use value
                errEx(4,i,:) = d11B(i,1)-d11B(i,2) + 2.*d11B(i,2).*rand(1,mCN);
            end
        end
        for j = 1:mCN
            for i = 1:size(age,1)
            t = 10;
            z = 1;
            while t>0.001
                z = z+1;
                KB = (-8966.9 -2890.53*errEx(3,i,j)^0.5 - 77.942*errEx(3,i,j) +...
                    1.728*errEx(3,i,j)^1.5 - 0.0996*errEx(3,i,j)^2)/(T(z-1,j)+273.15) + ...
                    (148.0248 + 137.1942*errEx(3,i,j)^0.5 + 1.62142*errEx(3,i,j)) + ...
                    (-24.4344 - 25.085*errEx(3,i,j)^0.5 - 0.2474*errEx(3,i,j))*log((T(z-1,j)+273.15)) + ...
                    0.053105*errEx(3,i,j)^0.5*(T(z-1,j)+273.15);
                pKB = -log10(exp(KB));
                pH(i,j) = pKB - log10(-((d11Bsw-errEx(4,i,j))/(d11Bsw-(1.0272*errEx(4,i,j)) - 1000*(1.0272 - 1))));
                T(z,j) = (errEx(1,i,j))./exp(errInt(j,1).*(errEx(3,i,j)-35) + ...
                        (pH(i,j)-8).*errInt(j,3) + errInt(j,4));% (d+err(1,5)*d1));
                T(z,j) = log(T(z,j))./errInt(j,2);
                t = abs(T(z,j)-T(z-1,j));
            end
            MgTemp(i,j) = T(z,j);
            end
        end
    end
    if relative(1)~=0 && numel(relative)>1 || numel(relative)>1
        for j = 1:mCN
            HolTemp = nanmean(MgTemp(idx(1):idx(size(idx,1)),j));
            MgTempRel(:,j) = MgTemp(:,j) - HolTemp;
        end
    end
end


if fig==1  % draw figure?
    close(figure(1))   % 1SD 2SD envelopes
    H = figure(1);
    if relative(1)~=0 || numel(relative)>1
        fill([age ; flipud(age)],...
            [prctile(MgTempRel,98,2) ; flipud(prctile(MgTempRel,2,2))],...
            'b','facealpha',0.1,'edgecolor','w')
        hold on
        fill([age ; flipud(age)],...
            [prctile(MgTempRel,84,2) ; flipud(prctile(MgTempRel,16,2))],...
            'b','facealpha',0.1,'edgecolor','w')
        plot(age,prctile(MgTempRel,50,2),'-b','linewidth',0.5)
        scatter(age,prctile(MgTempRel,50,2),20,'white','filled',...
            'markeredgecolor','b','linewidth',0.5)
        set(gcf,'color','white')
        xlabel('age (ka)')
        ylabel('\DeltaT (\circC)')
    else
        fill([age ; flipud(age)],...
            [prctile(MgTemp,98,2) ; flipud(prctile(MgTemp,2,2))],...
            'b','facealpha',0.1,'edgecolor','w')
        hold on
        fill([age ; flipud(age)],...
            [prctile(MgTemp,84,2) ; flipud(prctile(MgTemp,16,2))],...
            'b','facealpha',0.1,'edgecolor','w')
        plot(age,prctile(MgTemp,50,2),'-b','linewidth',0.5)
        scatter(age,prctile(MgTemp,50,2),20,'white','filled',...
            'markeredgecolor','b','linewidth',0.5)
        set(gcf,'color','white')
        xlabel('age (ka)')
        ylabel('T (\circC)')
    end
end

if nargout==3
    if unc==1
        TOutRel = [prctile(MgTempRel,98,2) prctile(MgTempRel,84,2) ...
            prctile(MgTempRel,50,2) prctile(MgTempRel,16,2) prctile(MgTempRel,2,2)];
    else
        TOutRel = MgTempRel;
    end
end

if unc==1
    TOut = [prctile(MgTemp,98,2) prctile(MgTemp,84,2) prctile(MgTemp,50,2) prctile(MgTemp,16,2) prctile(MgTemp,2,2)];
    pHOut = [prctile(pH,98,2) prctile(pH,84,2) prctile(pH,50,2) prctile(pH,16,2) prctile(pH,2,2)];
else
    TOut = MgTemp;
    pHOut = pH;
end
